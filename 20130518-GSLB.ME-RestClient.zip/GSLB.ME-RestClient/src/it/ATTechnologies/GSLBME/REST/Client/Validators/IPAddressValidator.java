package it.ATTechnologies.GSLBME.REST.Client.Validators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPAddressValidator
{
	private static Pattern pattern;
	private static Matcher matcher;

	private static final String IPADDRESS_PATTERN = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

	/**
	 * Checks if the given IP address is a valid IPv4
	 * 
	 * @param ipV4Address
	 *            the IP address to validate.
	 * @return true if the given address is a valid IPv4, false otherwise
	 */
	public static boolean isValid(String ipV4Address)
	{
		if (ipV4Address == null)
		{
			return false;
		}
		
		if (ipV4Address.equals("0.0.0.0") | ipV4Address.startsWith("127.")
				| ipV4Address.startsWith("10.") | ipV4Address.startsWith("192.168.")
				| ipV4Address.startsWith("172.16.") | ipV4Address.startsWith("172.17.")
				| ipV4Address.startsWith("172.18.") | ipV4Address.startsWith("172.19.")
				| ipV4Address.startsWith("172.20.") | ipV4Address.startsWith("172.21.")
				| ipV4Address.startsWith("172.22.") | ipV4Address.startsWith("172.23.")
				| ipV4Address.startsWith("172.24.") | ipV4Address.startsWith("172.25.")
				| ipV4Address.startsWith("172.26.") | ipV4Address.startsWith("172.27.")
				| ipV4Address.startsWith("172.28.") | ipV4Address.startsWith("172.29.")
				| ipV4Address.startsWith("172.30.") | ipV4Address.startsWith("172.31.")
				| ipV4Address.startsWith("224.") | ipV4Address.startsWith("225.")
				| ipV4Address.startsWith("226.") | ipV4Address.startsWith("227.")
				| ipV4Address.startsWith("228.") | ipV4Address.startsWith("229.")
				| ipV4Address.startsWith("230.") | ipV4Address.startsWith("231.")
				| ipV4Address.startsWith("232.") | ipV4Address.startsWith("233.")
				| ipV4Address.startsWith("234.") | ipV4Address.startsWith("235.")
				| ipV4Address.startsWith("236.") | ipV4Address.startsWith("237.")
				| ipV4Address.startsWith("238.") | ipV4Address.startsWith("239.")
				| ipV4Address.startsWith("240.") | ipV4Address.startsWith("241.")
				| ipV4Address.startsWith("242.") | ipV4Address.startsWith("243.")
				| ipV4Address.startsWith("244.") | ipV4Address.startsWith("245.")
				| ipV4Address.startsWith("246.") | ipV4Address.startsWith("247.")
				| ipV4Address.startsWith("248.") | ipV4Address.startsWith("249.")
				| ipV4Address.startsWith("250.") | ipV4Address.startsWith("251.")
				| ipV4Address.startsWith("252.") | ipV4Address.startsWith("253.")
				| ipV4Address.startsWith("254.")
				| ipV4Address.startsWith("255."))
			return false;

		pattern = Pattern.compile(IPADDRESS_PATTERN);
		matcher = pattern.matcher(ipV4Address);
		return matcher.matches();
	}
}