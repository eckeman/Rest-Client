package it.ATTechnologies.GSLBME.REST.Client;

import it.ATTechnologies.GSLBME.REST.Client.Constants.APIEncoding;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class CMDlineParser
{
	private CmdLineParser parser = null;

	/**
	 * Usage: GSLB.ME-RestClient [-u username -p password] [-encoding
	 * <json|xml>] [ [-get-zone zonename] | [...] ]
	 */

	@Option(name = "-h", usage = "Show usage help", aliases = { "--help" })
	boolean showHelp = false;

	@Option(name = "-u", usage = "Your GSLB.me username (mandatory)", aliases = { "--username" })
	private String username = null;

	@Option(name = "-p", usage = "Your GSLB.me password (mandatory)", aliases = { "--password" })
	private String password = null;

	@Option(name = "-e", usage = "Parameter: Desired output encoding (default: json)", aliases = { "--encoding" }, metaVar = "TYPE")
	public APIEncoding encoding = Constants.APIEncoding.json;

	@Option(name = "-gz", usage = "Action: Retrieves configuration for the given zone", aliases = { "--get-zone" }, metaVar = "NAME")
	private String actionGetZoneName = null;

	@Option(name = "-gg", usage = "Action: Retrieves configuration for the given geohost", aliases = { "--get-geohost" }, metaVar = "NAME")
	private String actionGetGeohostName = null;

	@Option(name = "-gr", usage = "Action: Retrieves all records for the given zone", aliases = { "--get-records" }, metaVar = "NAME")
	private String actionGetRecordsName = null;

	@Option(name = "-dyn", usage = "Action: Associates your current public IP address to the given FQDN. Optional parameters: -iface and -ttl", aliases = { "--dynamic" }, metaVar = "FQDN")
	private String actionDynFQDN = null;

	@Option(name = "-iface", usage = "Parameter: Interface to get the public IP from. The action -dyn / --dynamic requires this option", metaVar = "NAME")
	private String dynIFaceName = null;

	@Option(name = "-ttl", usage = "Parameter: TTL to use for dynamic IP FQDN updates. The action -dyn / --dynamic requires this option", metaVar = "SECONDS")
	private String dynTTLValue = null;

	// receives other command line parameters than options
	@Argument
	private List<String> arguments = new ArrayList<String>();

	public boolean isShowHelp()
	{
		return showHelp;
	}

	public APIEncoding getEncoding()
	{
		return encoding;
	}

	public String getUsername()
	{
		return username;
	}

	public String getPassword()
	{
		return password;
	}

	public String getActionGetZoneName()
	{
		return actionGetZoneName;
	}

	public String getActionGetGeohostName()
	{
		return actionGetGeohostName;
	}

	public String getActionGetRecordsName()
	{
		return actionGetRecordsName;
	}

	public String getActionDynFQDN()
	{
		return actionDynFQDN;
	}

	public String getDynIFaceName()
	{
		return dynIFaceName;
	}

	public String getDynTTLValue()
	{
		return dynTTLValue;
	}

	public List<String> getArguments()
	{
		return arguments;
	}

	public void setArguments(List<String> arguments)
	{
		this.arguments = arguments;
	}

	public CMDlineParser(String[] args) throws IOException, CmdLineException
	{
		parse(args);
	}

	private void parse(String[] args) throws IOException, CmdLineException
	{
		parser = new CmdLineParser(this);
		parser.setUsageWidth(80);
		parser.parseArgument(args);

		// you can parse additional arguments if you want.
		// parser.parseArgument("more","args");

		// after parsing arguments, you should check
		// if enough arguments are given.
		// if (arguments.isEmpty())
		// {
		// System.out.println("no additional parameters given");
		// }
		// throw new CmdLineException(parser, "No argument is given");

		// access non-option arguments
		// System.out.println("other arguments are:");
		// for (String s : arguments)
		// System.out.println(s);
	}

	public void printHelp()
	{
		if (parser != null)
		{
			System.err.println(Constants.RESTCLIENT_BANNER);
			System.err.println(Constants.RESTCLIENT_USAGE_EXAMPLE);
			System.err.println();
			parser.printUsage(System.err);
			System.err.println();
			System.err.println(Constants.RESTCLIENT_SAMPLE_COMMANDS);
			System.err.println();
		}
	}
}
