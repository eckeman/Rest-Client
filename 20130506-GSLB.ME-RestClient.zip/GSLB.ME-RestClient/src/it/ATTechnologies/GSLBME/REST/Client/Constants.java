package it.ATTechnologies.GSLBME.REST.Client;

public class Constants
{
	public final static String RESTCLIENT_API_ENDPOINT = "https://api.gslb.me";

	public final static String RESTCLIENT_BANNER = "GSLB.me REST API client 1.0beta - http://www.gslb.me\n";
	public final static String RESTCLIENT_USAGE_EXAMPLE = "./sh.GSLB.ME-RestClient [-u username] [-p password] [action] [options]";

	public final static int RETURNCODE_OK = 0;
	public final static int RETURNCODE_AUTH_FAILED = 1;
	public final static int RETURNCODE_INVALID_PARAMETERS_MULTIPLE_ACTIONS = 900;
	public final static int RETURNCODE_INVALID_PARAMETERS_MISSING_ACTION = 901;
	public final static int RETURNCODE_INTERNAL_ERROR = 999;

	public final static String RETURNCODE_MSG_AUTH_FAILED = "Authentication failed";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_MULTIPLE_ACTIONS = "Invalid parameters, only one action can be specified";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_MISSING_ACTION = "Invalid parameters, action is missing";
	public final static String RETURNCODE_MSG_INTERNAL_ERROR = "Internal error";

	public static enum APIEncoding
	{
		json, xml
	}
}