package it.ATTechnologies.GSLBME.REST.Client;

import java.io.IOException;

import javax.ws.rs.core.MediaType;

import org.kohsuke.args4j.CmdLineException;

import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class GSLBmeRestClient
{
	public static void main(String[] args)
	{
		CMDlineParser cmdline = null;
		WebResource gslbMeAPI = null;

		try
		{
			cmdline = new CMDlineParser(args);

			if (args.length == 0)
			{
				cmdline.printHelp();
				return;
			}

			if (cmdline.isShowHelp())
			{
				cmdline.printHelp();
				return;
			}

			if (cmdline.getUsername() == null || cmdline.getPassword() == null)
			{
				System.err
						.println("Username (-u) and password (-p) are mandatory");
				return;
			}

			gslbMeAPI = APIEndpoint.getWebResource(cmdline.getUsername(),
					cmdline.getPassword());

		} catch (IOException e)
		{
			System.err.println(e.getMessage());
			System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
		} catch (CmdLineException e)
		{
			System.err.println(e.getMessage());
			System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
		}

		int returnCode = Constants.RETURNCODE_INTERNAL_ERROR;

		if (gslbMeAPI == null)
		{
			System.err.println(Constants.RETURNCODE_MSG_INTERNAL_ERROR);
			System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
		}

		// Sets the encoding type
		String encoding = MediaType.APPLICATION_JSON;

		if (cmdline.getEncoding().equals(Constants.APIEncoding.json))
		{
			encoding = MediaType.APPLICATION_JSON;
		} else if (cmdline.getEncoding().equals(Constants.APIEncoding.xml))
		{
			encoding = MediaType.APPLICATION_XML;
		} else
		{
			System.err.println(Constants.RETURNCODE_MSG_INTERNAL_ERROR);
			System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
		}

		// Switches the selected API method
		int howManyMethods = 0;

		if (cmdline.getGetZoneName() != null)
			howManyMethods++;

		if (cmdline.getGetGeohostName() != null)
			howManyMethods++;

		if (cmdline.getGetRecordsName() != null)
			howManyMethods++;

		// One single method must be specified
		if (howManyMethods > 1)
		{
			System.err
					.println(Constants.RETURNCODE_MSG_INVALID_PARAMETERS_MULTIPLE_ACTIONS);
			System.exit(Constants.RETURNCODE_INVALID_PARAMETERS_MULTIPLE_ACTIONS);
		}

		ClientResponse b = null;

		if (cmdline.getGetZoneName() != null)
		{
			b = gslbMeAPI.path("zone").path(cmdline.getGetZoneName())
					.accept(encoding).get(ClientResponse.class);
		} else if (cmdline.getGetGeohostName() != null)
		{
			b = gslbMeAPI.path("geohost").path(cmdline.getGetGeohostName())
					.accept(encoding).get(ClientResponse.class);
		} else if (cmdline.getGetRecordsName() != null)
		{
			b = gslbMeAPI.path("records").path(cmdline.getGetRecordsName())
					.accept(encoding).get(ClientResponse.class);
		} else
		{
			System.err
					.println(Constants.RETURNCODE_MSG_INVALID_PARAMETERS_MISSING_ACTION);
			System.exit(Constants.RETURNCODE_INVALID_PARAMETERS_MISSING_ACTION);
		}

		// Handles HTTP status code
		int httpStatus = b.getStatus();

		switch (httpStatus)
		{
		case 200:
			System.err.println(b.getEntity(String.class));
			returnCode = Constants.RETURNCODE_OK;
			break;

		case 400:
			break;
		case 401:
			System.err.println(Constants.RETURNCODE_MSG_AUTH_FAILED);
			returnCode = Constants.RETURNCODE_AUTH_FAILED;
			break;
		case 404:
			System.err.println(b.getEntity(String.class));
			break;
		case 403:
			System.err.println(b.getEntity(String.class));
			break;
		case 406:
			System.err.println(b.getEntity(String.class));
			break;
		case 500:
			System.err.println(b.getEntity(String.class));
			break;
		case 503:
			System.err.println(b.getEntity(String.class));
			break;

		default:
			break;
		}

		System.exit(returnCode);
	}
}
