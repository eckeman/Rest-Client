package it.ATTechnologies.GSLBME.REST.Client;

import it.ATTechnologies.GSLBME.REST.Client.Constants.APIEncoding;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class CMDlineParser
{
	private CmdLineParser parser = null;

	/**
	 * Usage: GSLB.ME-RestClient [-u username -p password] [-encoding
	 * <json|xml>] [ [-get-zone zonename] | [...] ]
	 */

	@Option(name = "-h", usage = "Show usage help", aliases = { "--help" })
	boolean showHelp = false;

	@Option(name = "-u", usage = "Your GSLB.me username (mandatory)", aliases = { "--username" })
	private String username = null;

	@Option(name = "-p", usage = "Your GSLB.me password (mandatory)", aliases = { "--password" })
	private String password = null;

	@Option(name = "-e", usage = "Option: Desired output encoding (default: json)", aliases = { "--encoding" }, metaVar = "TYPE")
	public APIEncoding encoding = Constants.APIEncoding.json;

	@Option(name = "-gz", usage = "Action: Retrieves configuration for the given zone", aliases = { "--get-zone" }, metaVar = "NAME")
	private String getZoneName = null;

	@Option(name = "-gg", usage = "Action: Retrieves configuration for the given geohost", aliases = { "--get-geohost" }, metaVar = "NAME")
	private String getGeohostName = null;

	@Option(name = "-gr", usage = "Action: Retrieves all records for the given zone", aliases = { "--get-records" }, metaVar = "NAME")
	private String getRecordsName = null;

	// receives other command line parameters than options
	@Argument
	private List<String> arguments = new ArrayList<String>();

	public boolean isShowHelp()
	{
		return showHelp;
	}

	public void setShowHelp(boolean showHelp)
	{
		this.showHelp = showHelp;
	}

	public APIEncoding getEncoding()
	{
		return encoding;
	}

	public String getUsername()
	{
		return username;
	}

	public String getPassword()
	{
		return password;
	}

	public String getGetZoneName()
	{
		return getZoneName;
	}

	public String getGetGeohostName()
	{
		return getGeohostName;
	}

	public String getGetRecordsName()
	{
		return getRecordsName;
	}

	public List<String> getArguments()
	{
		return arguments;
	}

	public void setArguments(List<String> arguments)
	{
		this.arguments = arguments;
	}

	public CMDlineParser(String[] args) throws IOException, CmdLineException
	{
		parse(args);
	}

	private void parse(String[] args) throws IOException, CmdLineException
	{
		parser = new CmdLineParser(this);
		parser.setUsageWidth(80);
		parser.parseArgument(args);

		// you can parse additional arguments if you want.
		// parser.parseArgument("more","args");

		// after parsing arguments, you should check
		// if enough arguments are given.
		// if (arguments.isEmpty())
		// {
		// System.out.println("no additional parameters given");
		// }
		// throw new CmdLineException(parser, "No argument is given");

		// access non-option arguments
		// System.out.println("other arguments are:");
		// for (String s : arguments)
		// System.out.println(s);
	}

	public void printHelp()
	{
		if (parser != null)
		{
			System.err.println(Constants.RESTCLIENT_BANNER);
			System.err.println(Constants.RESTCLIENT_USAGE_EXAMPLE);
			System.err.println();
			parser.printUsage(System.err);
			System.err.println();
		}
	}
}
