package it.ATTechnologies.GSLBME.REST.Client;

import java.net.URI;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.UriBuilder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

public class APIEndpoint
{
	/**
	 * Returns the api.gslb.me base URI
	 * 
	 * @return the api.gslb.me base URI
	 */
	private static URI getBaseURI()
	{
		return UriBuilder.fromUri(Constants.RESTCLIENT_API_ENDPOINT).build();
	}

	/**
	 * Returns the api.gslb.me web resource endpoint
	 * 
	 * @return the api.gslb.me web resource endpoint
	 */
	public static WebResource getWebResource(String authUsername,
			String authPassword)
	{
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers()
			{
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs,
					String authType)
			{
			}

			public void checkServerTrusted(X509Certificate[] certs,
					String authType)
			{
			}
		} };

		// Install the all-trusting trust manager
		SSLContext sc = null;

		try
		{
			sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new SecureRandom());
		} catch (KeyManagementException e)
		{
			System.out.println(e.getMessage());
			System.exit(1);
		} catch (NoSuchAlgorithmException e)
		{
			System.out.println(e.getMessage());
			System.exit(1);
		}
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		ClientConfig config = new DefaultClientConfig();
		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
				new HTTPSProperties(new HostnameVerifier() {

					@Override
					public boolean verify(String s, SSLSession sslSession)
					{
						return true;
					}
				}, sc));
		Client client = Client.create(config);
		client.addFilter(new HTTPBasicAuthFilter(authUsername, authPassword));

		return client.resource(getBaseURI());
	}
}