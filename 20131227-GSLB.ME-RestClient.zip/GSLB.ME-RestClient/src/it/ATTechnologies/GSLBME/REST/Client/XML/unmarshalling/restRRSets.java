package it.ATTechnologies.GSLBME.REST.Client.XML.unmarshalling;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement
@XmlSeeAlso(rrset.class)
public class restRRSets
{
	@XmlElement
	ArrayList<rrset> rrset = new ArrayList<rrset>();

	public restRRSets()
	{
	}

	public ArrayList<rrset> getRrsetItems()
	{
		return this.rrset;
	}

	public void setRrsetItems(ArrayList<rrset> rrsetItems)
	{
		this.rrset = rrsetItems;
	}
}
