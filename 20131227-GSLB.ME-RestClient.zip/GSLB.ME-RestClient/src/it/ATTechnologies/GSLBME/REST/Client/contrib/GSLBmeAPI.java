package it.ATTechnologies.GSLBME.REST.Client.contrib;

import javax.ws.rs.core.MediaType;

import it.ATTechnologies.GSLBME.REST.Client.APIEndpoint;

import com.sun.jersey.api.client.WebResource;

public class GSLBmeAPI
{
	private static WebResource gslbMeAPIendpoint = null;
	private static String encoding = MediaType.APPLICATION_JSON;

	public static void login(String username, String password)
	{
		gslbMeAPIendpoint = APIEndpoint.getWebResource(username, password);
	}

	public static WebResource get()
	{
		return gslbMeAPIendpoint;
	}

	public static String getEncoding()
	{
		return encoding;
	}

	public static void setEncoding(String encoding)
	{
		GSLBmeAPI.encoding = encoding;
	}
}