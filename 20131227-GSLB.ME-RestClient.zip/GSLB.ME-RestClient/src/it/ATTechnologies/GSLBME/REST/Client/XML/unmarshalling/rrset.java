package it.ATTechnologies.GSLBME.REST.Client.XML.unmarshalling;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class rrset
{
	private int id;
	private String name;
	private boolean readonly;
	private long TTL;
	private String type;
	private String value;

	public rrset()
	{
	}

	public int getId()
	{
		return id;
	}

	@XmlElement
	public void setId(int id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	@XmlElement
	public void setName(String name)
	{
		this.name = name;
	}

	public boolean isReadonly()
	{
		return readonly;
	}

	@XmlElement
	public void setReadonly(boolean readonly)
	{
		this.readonly = readonly;
	}

	public long getTTL()
	{
		return TTL;
	}

	@XmlElement
	public void setTTL(long tTL)
	{
		TTL = tTL;
	}

	public String getType()
	{
		return type;
	}

	@XmlElement
	public void setType(String type)
	{
		this.type = type;
	}

	public String getValue()
	{
		return value;
	}

	@XmlElement
	public void setValue(String value)
	{
		this.value = value;
	}

}