package it.ATTechnologies.GSLBME.REST.Client;

public class Constants
{
	public final static String RESTCLIENT_API_ENDPOINT = "https://api.gslb.me";

	public final static String RESTCLIENT_BANNER = "GSLB.me REST API client 1.2 - http://www.gslb.me\n";
	public final static String RESTCLIENT_USAGE_EXAMPLE = "Linux  : ./sh.GSLB.ME-RestClient [-u username] [-p password] [action] [parameters]\n"
			+ "Windows: GSLB.me-RestClient.bat [-u username] [-p password] [action] [parameters]";
	public final static String RESTCLIENT_SAMPLE_COMMANDS = "Usage examples:"
			+ "\n\nRetrieving a zone configuration:\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -gz [zone name]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -gz [zone name]"
			+ "\n\nRetrieving a geohost configuration:\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -gg [geohost name]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -gg [geohost name]"
			+ "\n\nRetrieving all records for the given zone:\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -gr [zone name]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -gr [zone name]"
			+ "\n\nUpdating a FQDN with the public (dynamic) IP of the specified interface without/with custom TTL:\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -dyn [fqdn] -iface [interface name]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -dyn [fqdn] -iface [interface name]\n\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -dyn [fqdn] -iface [interface name] -ttl [seconds]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -dyn [fqdn] -iface [interface name] -ttl [seconds]"
			+ "\n\nUpdating a FQDN with the public (dynamic) IP using automatic IP detection without/with custom TTL:\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -dyn [fqdn]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -dyn [fqdn]\n\n"
			+ "  Linux  : ./sh.GSLB.ME-RestClient -u [username] -p [password] -dyn [fqdn] -ttl [seconds]\n"
			+ "  Windows: GSLB.me-RestClient.bat -u [username] -p [password] -dyn [fqdn] -ttl [seconds]";

	public final static int RETURNCODE_OK = 0;
	public final static int RETURNCODE_AUTH_FAILED = 1;
	public final static int RETURNCODE_CANT_GET_IP = 2;
	public final static int RETURNCODE_INVALID_FQDN = 3;
	public final static int RETURNCODE_INVALID_FQDN_MUST_BE_UNIQUE = 4;
	public final static int RETURNCODE_INVALID_FQDN_MUST_EXIST = 5;
	public final static int RETURNCODE_INVALID_FQDN_MUST_BE_A = 6;
	public final static int RETURNCODE_INVALID_INTERFACE = 7;
	public final static int RETURNCODE_NOTUPDATING_SAME_IP = 8;
	public final static int RETURNCODE_INVALID_IP_MUST_BE_PUBLIC = 9;
	public final static int RETURNCODE_INVALID_PARAMETERS_MULTIPLE_ACTIONS = 900;
	public final static int RETURNCODE_INVALID_PARAMETERS_MISSING_ACTION = 901;
	public final static int RETURNCODE_INVALID_PARAMETERS_MISSING_PARAMETER = 902;
	public final static int RETURNCODE_INVALID_PARAMETERS_OPTION_MISMATCH = 903;
	public final static int RETURNCODE_NETWORK_ERROR = 998;
	public final static int RETURNCODE_INTERNAL_ERROR = 999;

	public final static String RETURNCODE_MSG_OK = "Done";
	public final static String RETURNCODE_MSG_AUTH_FAILED = "Authentication failed";
	public final static String RETURNCODE_MSG_CANT_GET_IP = "Can't get IP address";
	public final static String RETURNCODE_MSG_INVALID_FQDN = "Invalid FQDN";
	public final static String RETURNCODE_MSG_FQDN_MUST_BE_UNIQUE = "Dynamic FQDN must be a unique record";
	public final static String RETURNCODE_MSG_FQDN_MUST_EXIST = "Dynamic FQDN must be an existing record";
	public final static String RETURNCODE_MSG_FQDN_MUST_BE_A = "Dynamic FQDN must be an \"A\" record";
	public final static String RETURNCODE_MSG_INVALID_INTERFACE = "The given interface can't be found";
	public final static String RETURNCODE_MSG_NOT_UPDATING_SAME_IP = "The dynamic IP has not changed, not updating";
	public final static String RETURNCODE_MSG_INVALID_IP_MUST_BE_PUBLIC = "The dynamic IP must be public";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_MULTIPLE_ACTIONS = "Invalid parameters, only one action can be specified";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_MISSING_ACTION = "Invalid syntax, action is missing";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_MISSING_PARAMETER = "Invalid syntax, parameter is missing";
	public final static String RETURNCODE_MSG_INVALID_PARAMETERS_OPTION_MISMATCH = "Invalid parameter for the specified option";
	public final static String RETURNCODE_MSG_NETWORK_ERROR = "Network error";
	public final static String RETURNCODE_MSG_INTERNAL_ERROR = "Internal error";

	public static enum APIEncoding
	{
		json, xml
	}
}