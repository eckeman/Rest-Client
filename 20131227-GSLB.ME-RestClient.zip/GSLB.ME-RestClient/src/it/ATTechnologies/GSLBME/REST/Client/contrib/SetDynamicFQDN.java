package it.ATTechnologies.GSLBME.REST.Client.contrib;

import it.ATTechnologies.GSLBME.REST.Client.CMDlineParser;
import it.ATTechnologies.GSLBME.REST.Client.Constants;
import it.ATTechnologies.GSLBME.REST.Client.Validators.IPAddressValidator;
import it.ATTechnologies.GSLBME.REST.Client.XML.unmarshalling.restRRSets;
import it.ATTechnologies.GSLBME.REST.Client.XML.unmarshalling.rrset;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.ClientResponse;

public class SetDynamicFQDN
{
	/**
	 * Sets an FQDN record to the IP address of the specified interface or using
	 * IP autodetection
	 * 
	 * @param cmdline
	 *            the cmdline to get the FQDN name and the IP address detection
	 *            method (either interface name o autodetect)
	 * @return
	 */
	public static ClientResponse set(CMDlineParser cmdline)
	{
		String dynFQDN = cmdline.getActionDynFQDN();
		String myIPAddress = null;
		String dynTTL = "60";

		if (cmdline.getDynTTLValue() != null)
			dynTTL = cmdline.getDynTTLValue();

		if (cmdline.getDynIFaceName() == null)
		{
			// no -iface specified, let's autodetect the public IP address
			try
			{
				myIPAddress = GetMyIP.getIp();
			} catch (Exception e)
			{
				System.err.println(e.getStackTrace());
				System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
			}
		} else
		{
			NetworkInterface nif = null;

			try
			{
				nif = NetworkInterface.getByName(cmdline.getDynIFaceName());

				if (nif == null)
				{
					System.err
							.println(Constants.RETURNCODE_MSG_INVALID_INTERFACE);
					System.exit(Constants.RETURNCODE_INVALID_INTERFACE);
				}

				Enumeration<InetAddress> nifAddresses = nif.getInetAddresses();

				boolean haveWeFoundIPv4 = false;

				while (nifAddresses.hasMoreElements() && !haveWeFoundIPv4)
				{
					InetAddress ip = nifAddresses.nextElement();
					myIPAddress = ip.getHostAddress();

					// If sourceStr contains ":" but no "." -> IPv6
					// If
					// sourceStr.matches("^.[0-9]{1,3}/..[0-9]{1,3}/..[0-9]{1,3}/..[0-9]{1,3}")
					// == true) -> IPv4
					// If sourceStr contains "." -> FQDN host name

					if (myIPAddress.contains(":") && !myIPAddress.contains("."))
					{
						// IPv6
					} else if (IPAddressValidator.isValid(myIPAddress))
					{
						// IPv4
						haveWeFoundIPv4 = true;
					} else
					{
						System.err
								.println(Constants.RETURNCODE_MSG_INVALID_IP_MUST_BE_PUBLIC);
						System.exit(Constants.RETURNCODE_INVALID_IP_MUST_BE_PUBLIC);
					}
				}
			} catch (SocketException e)
			{
				System.err.println(e.getStackTrace());
				System.exit(Constants.RETURNCODE_INTERNAL_ERROR);
			}
		}

		if (myIPAddress == null)
		{
			System.err.println(Constants.RETURNCODE_MSG_CANT_GET_IP);
			System.exit(Constants.RETURNCODE_CANT_GET_IP);
		}

		StringTokenizer fqdnTokens = new StringTokenizer(dynFQDN, ".");
		int howManyTokens = fqdnTokens.countTokens();
		String token[] = new String[howManyTokens];

		int i = 0;

		while (fqdnTokens.hasMoreTokens())
		{
			token[i++] = fqdnTokens.nextToken();
		}

		if (howManyTokens < 3)
		{
			System.err.println(Constants.RETURNCODE_MSG_INVALID_FQDN);
			System.exit(Constants.RETURNCODE_INVALID_FQDN);
		}

		// Looks for the zone the FQDN belongs to starting to match from the
		// second level (domain.tld)
		String zoneToFind = token[howManyTokens - 1];

		ClientResponse cr = null;

		int currentToken = howManyTokens - 1;
		int status = 0;
		while (currentToken > 0 && status != 200)
		{
			zoneToFind = token[--currentToken] + "." + zoneToFind;

			try
			{
				cr = GSLBmeAPI.get().path("records").path(zoneToFind)
						.accept(MediaType.APPLICATION_XML)
						.get(ClientResponse.class);
			} catch (Exception e)
			{
				System.err.println(Constants.RETURNCODE_MSG_NETWORK_ERROR
						+ ": " + e.getMessage());
				System.exit(Constants.RETURNCODE_NETWORK_ERROR);
			}

			status = cr.getStatus();
		}

		if (status == 401)
		{
			System.err.println(Constants.RETURNCODE_MSG_AUTH_FAILED);
			System.exit(Constants.RETURNCODE_AUTH_FAILED);
		}

		// We got all records for the given zone, let's parse them to find the
		// rrset for the requested FQDN where we have to set the IP address
		String recordName = token[0];

		for (int j = 1; j < currentToken; j++)
		{
			recordName += "." + token[j];
		}

		restRRSets allRecords = cr.getEntity(restRRSets.class);

		ArrayList<rrset> records = allRecords.getRrsetItems();

		int howManyMatchingRecordsFound = 0;
		int matchingRecordID = 0;
		String matchingRecordType = "";
		String matchingRecordName = "";
		String matchingRecordIP = "";

		for (rrset thisRecord : records)
		{
			if (thisRecord.getType().equalsIgnoreCase("A"))
			{
				String thisRecordName = (thisRecord.getName().equals("@") == false ? thisRecord
						.getName() + "." + zoneToFind
						: thisRecord.getName());

				// System.err.println("thisrecordname[" + thisRecordName
				// + "] dynfqdn[" + dynFQDN + "] zonetofind[" + zoneToFind
				// + "]");

				if (thisRecordName.equalsIgnoreCase(dynFQDN)
						|| (thisRecordName.equals("@") && dynFQDN
								.equalsIgnoreCase(zoneToFind)))
				{
					// The dynamic FQDN to update has been matched
					howManyMatchingRecordsFound++;
					matchingRecordID = thisRecord.getId();
					matchingRecordType = thisRecord.getType();
					matchingRecordName = thisRecord.getName();
					matchingRecordIP = thisRecord.getValue();

					// System.err.println("FOUND");
				}
			}
		}

		if (howManyMatchingRecordsFound > 1)
		{
			System.err.println(Constants.RETURNCODE_MSG_FQDN_MUST_BE_UNIQUE);
			System.exit(Constants.RETURNCODE_INVALID_FQDN_MUST_BE_UNIQUE);
		} else if (howManyMatchingRecordsFound == 0)
		{
			System.err.println(Constants.RETURNCODE_MSG_FQDN_MUST_EXIST);
			System.exit(Constants.RETURNCODE_INVALID_FQDN_MUST_EXIST);
		}

		if (matchingRecordType.equalsIgnoreCase("A") == false)
		{
			System.err.println(Constants.RETURNCODE_MSG_FQDN_MUST_BE_A);
			System.exit(Constants.RETURNCODE_INVALID_FQDN_MUST_BE_A);
		}

		if (matchingRecordIP.equalsIgnoreCase(myIPAddress))
		{
			System.err.println(Constants.RETURNCODE_MSG_NOT_UPDATING_SAME_IP);
			System.exit(Constants.RETURNCODE_NOTUPDATING_SAME_IP);
		} else
		{
			// System.err.println("Setting IP [" + myIPAddress + "] for ["
			// + dynFQDN + "]");
		}

		// PUT
		// /record/zone_name/record_id/record_name/record_type/record_value/record_TTL
		// HTTP/1.0
		try
		{
			cr = GSLBmeAPI.get().path("record").path(zoneToFind)
					.path(String.valueOf(matchingRecordID))
					.path(matchingRecordName).path("A").path(myIPAddress)
					.path(dynTTL).accept(GSLBmeAPI.getEncoding())
					.put(ClientResponse.class, "");
		} catch (Exception e)
		{
			System.err.println(Constants.RETURNCODE_MSG_NETWORK_ERROR + ": "
					+ e.getMessage());
			System.exit(Constants.RETURNCODE_NETWORK_ERROR);
		}

		// System.err.println("Set record: " + cr.getStatus());

		if (cr.getStatus() != 200)
		{
			// Record modification failed, return the relevant return code
			return cr;
		}

		// POST /commit/zone/zone_name HTTP/1.0

		// Record modification successful, let's commit the change
		try
		{
			cr = GSLBmeAPI.get().path("commit").path("zone").path(zoneToFind)
					.accept(GSLBmeAPI.getEncoding())
					.post(ClientResponse.class, "");
		} catch (Exception e)
		{
			System.err.println(Constants.RETURNCODE_MSG_NETWORK_ERROR + ": "
					+ e.getMessage());
			System.exit(Constants.RETURNCODE_NETWORK_ERROR);
		}

		// System.err.println("Commit [" + zoneToFind + "]: " + cr.getStatus());

		return cr;
	}
}